// [ShopShields.java]

// Imports
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

// Class 
class ShopShields extends JFrame 
{
  
  // Variables
  static boolean open;
  JButton back = new JButton("Back");
  JPanel contentPane = new JPanel();
  static LinkedList<Shield> shields = new LinkedList<Shield>();
  
  // Constructor
  ShopShields() {
    
    // Set JFrame
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setTitle("Armor");
    setSize(700,700);
    
    // Back JButton
    back.setFont(Menu.font1);
    back.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        open = false;
        dispose();
      }
    });
    back.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Grid Layout
    contentPane.setLayout(new GridLayout(5, 5));
    
    // Add shields to shop
    for (int i = 0; i < shields.size(); i++) {
      Shield s = shields.get(i);
      JButton armorItem = new JButton(new ImageIcon(Shield.sprites[s.currentSprite - 1]));
      armorItem.setLayout(new BorderLayout());
      JLabel name = new JLabel(s.name);
      name.setFont(Menu.font1);
      JLabel shield = new JLabel(s.shield + " shield");
      shield.setFont(Menu.font1);
      JLabel gold = new JLabel(s.cost + " gold");
      gold.setFont(Menu.font1);
      armorItem.add(BorderLayout.NORTH, name);
      armorItem.add(BorderLayout.CENTER, shield);
      armorItem.add(BorderLayout.SOUTH, gold);
      armorItem.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (GamePanel.p.gold >= s.cost && !GamePanel.inventory.contains(s)) {
            GamePanel.inventory.add(s);
            GamePanel.p.gold = GamePanel.p.gold - s.cost;
          }
          Inventory.getCurrentShield();
        }
      });
      contentPane.add(armorItem);
    }
    
    // Add JButton
    contentPane.add(back);
    
    // Add JPanel
    add(contentPane);
    
    // Set Visible
    setResizable(false);
    setVisible(true);
  }
  
  // Show the shield shop
  static void showShields() {
    open = true;
    
    // Open JFrame
    ShopShields s = new ShopShields();
  }
}