// [ShopWeapons.java]

// Imports
import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

// Class
class ShopWeapons extends JFrame 
{
  
  // Variables
  static boolean open;
  JButton back = new JButton("Back");
  JPanel contentPane = new JPanel();
  static LinkedList<Weapon> weapons = new LinkedList<Weapon>();
  
  // Construtors
  ShopWeapons() {
    
    // Set up JFrame
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setTitle("Weapons");
    setSize(700,700);
    
    // Back JButton
    back.setFont(Menu.font1);
    back.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        open = false;
        dispose();
      }
    });
    back.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // GridLayout
    contentPane.setLayout(new GridLayout(5, 5));
    
    // Add Weapon Items
    for (int i = 0; i < weapons.size(); i++) {
      Weapon w = weapons.get(i);
      JButton weaponItem = new JButton(new ImageIcon(Weapon.sprites[w.currentSprite - 1]));
      weaponItem.setLayout(new BorderLayout());
      JLabel name = new JLabel(w.name);
      name.setFont(Menu.font1);
      name.setForeground(Color.RED);
      JLabel damage = new JLabel(w.attack + " attack");
      damage.setFont(Menu.font1);
      damage.setForeground(Color.RED);
      JLabel gold = new JLabel(w.cost + " gold");
      gold.setFont(Menu.font1);
      gold.setForeground(Color.RED);
      weaponItem.add(BorderLayout.NORTH, name);
      weaponItem.add(BorderLayout.CENTER, damage);
      weaponItem.add(BorderLayout.SOUTH, gold);
      weaponItem.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (GamePanel.p.gold >= w.cost && !weapons.contains(w)) {
            GamePanel.inventory.add(w);
            GamePanel.p.gold = GamePanel.p.gold - w.cost;
          }
          Inventory.getCurrentWeapon();
        }
      });
      contentPane.add(weaponItem);
    }
    
    // Add JButton
    contentPane.add(back);
    
    // Add JFrame
    add(contentPane);
    
    // Set Visible
    setResizable(false);
    setVisible(true);
  }
  
  // Show Weapon Shop
  static void showWeapons() {
    open = true;
    // Open WeaponShop JFrame
    ShopWeapons s = new ShopWeapons();
  }
}