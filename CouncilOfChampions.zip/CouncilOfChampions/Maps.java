// [Maps.java]

// Imports
import java.util.*;
import java.io.*;
import java.awt.image.*;
import javax.imageio.*;
import java.awt.*;

// Class
class Maps 
{
  
  // Variables
  static Map maps[][][] = new Map [6][50][50];
  static BufferedImage mapBackgrounds[] = new BufferedImage[6];
  
  // Load the maps and the images
  static void getMaps() throws IOException{
    
    // Loads the maps from the text files
    for (int i = 0; i < 6; i++) {
      String filename = "Load/Map" + (i + 1) + ".txt";
      File mapFile = new File(filename);
      Scanner sc = new Scanner(mapFile); 
      for (int row = 0; row < 50; row++) {
        for (int col = 0; col < 50; col++) {
          if (sc.hasNextInt()) {
            int x = sc.nextInt();
            if (i == 0 && row == 49 && col == 49) {
            }
            if (x == 0) {
              maps[i][row][col] = null;
            } else {
              maps[i][row][col] = new Land(0);
            }
          }
        }
      }
    }
    
    // Get the backgrounds
    mapBackgrounds[0] = ImageIO.read(new File("Image/home.png"));
    mapBackgrounds[1] = ImageIO.read(new File("Image/field1.jpg"));
    mapBackgrounds[2] = ImageIO.read(new File("Image/field2.jpg"));
    mapBackgrounds[3] = ImageIO.read(new File("Image/field3.jpg"));
    mapBackgrounds[4] = ImageIO.read(new File("Image/cave.png"));
    mapBackgrounds[5] = ImageIO.read(new File("Image/bossCave.png"));
  }
}