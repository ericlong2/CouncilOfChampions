// [Map.java]

// Import
import java.awt.image.*;

// Class
abstract class Map 
{
  
  // Variable
  int currentSprite;
  
  // Constructor
  Map(int currentSprite) {
    this.currentSprite = currentSprite;
  }
}