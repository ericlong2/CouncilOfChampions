// [NPC.java]

// Imports
import javax.imageio.*;
import java.awt.image.*;
import java.io.*;
import java.awt.*;
import java.util.*;

// Class
class NPC extends Life 
{
  
  // Variables
  static BufferedImage[][] sprites;
  Quest quest;
  int npcNum;
  boolean receivedQuest;
  
  // Constructor
  NPC(int currentSprite, Quest quest, int npcNum) {
    super(currentSprite);
    this.quest = quest;
    this.npcNum = npcNum;
    this.receivedQuest = false;
  }
  
  // Loading sprites
  static void loadSprites() throws IOException{ 
    BufferedImage sheet = ImageIO.read(new File("Image/npc.png"));
    sprites = new BufferedImage[8][4 * 3];
    int width = sheet.getWidth() / 12;
    int height = sheet.getHeight() / 8;
    for (int j = 0; j < 8; j++) {
      for (int i = 0; i < 12.; i++) {
        sprites[(j / 4) * 4 + (i / 3)][(j % 4) * 3 + (i % 3)] = sheet.getSubimage(i * width,j * height,width,height);
      }
    }
  }
  
  // Different types of NPCs
  static LinkedList<NPC> npcs = new LinkedList<NPC>();
  
  // Loading different NPCs
  static void load () throws IOException {
    File npcfile = new File("Load/NPC.txt");
    Scanner sc = new Scanner(npcfile);
    while(sc.hasNext()) {
      String details = sc.nextLine();
      int expReward = sc.nextInt();
      int goldReward = sc.nextInt();
      int questNum = sc.nextInt();
      int npcNum = sc.nextInt();
      sc.nextLine();
      npcs.add(new NPC(8, new Quest(details, expReward, goldReward, questNum), npcNum));
    }
  }
  
  // Spawning NPCs
  static void spawn() throws NullPointerException {
    for (int i = 0; i < 8; i++) {
      while(true) {
        rand = new Random();
        
        // Random Location
        int x = rand.nextInt(50);
        int y = rand.nextInt(50);
        
        // Checks if there is space
        if (GamePanel.currentMap[y][x] instanceof Land && GamePanel.currentLifeMap[y][x] == null) {
          NPC n = npcs.get(i);
          GamePanel.currentLifeMap[y][x] = new NPC(n.currentSprite, n.quest, n.npcNum);
          break;
        }
      }
    }
  }
  
  // Moving NPCs on map
  static void move() throws NullPointerException {
    for (int i = 0; i < 50; i++) {
      for (int j = 0; j < 50; j++) {
        
        // Checks if it is an NPC
        if (GamePanel.currentLifeMap[i][j] instanceof NPC) {
          
          // 50% chance of moving
          int move = rand.nextInt(2);
          if (move == 1) {
            
            // Gets Direction
            int direction = rand.nextInt(4);
            
            // Moving Left
            if (direction == GamePanel.LEFT && j > 0) {
              GamePanel.currentLifeMap[i][j].currentSprite = 11;
              if (GamePanel.currentMap[i][j - 1] instanceof Land && GamePanel.currentLifeMap[i][j - 1] == null) {
                GamePanel.currentLifeMap[i][j - 1] = GamePanel.currentLifeMap[i][j];
                GamePanel.currentLifeMap[i][j] = null;
              }
              
            // Moving Up
            } else if (direction == GamePanel.UP && i > 0) {
              GamePanel.currentLifeMap[i][j].currentSprite = 2;
              if (GamePanel.currentMap[i - 1][j] instanceof Land && GamePanel.currentLifeMap[i - 1][j] == null) {
                GamePanel.currentLifeMap[i - 1][j] = GamePanel.currentLifeMap[i][j];
                GamePanel.currentLifeMap[i][j] = null;
              }
              
            // Moving Right
            } else if (direction == GamePanel.RIGHT && j < 49) {
              GamePanel.currentLifeMap[i][j].currentSprite = 5;
              if (GamePanel.currentMap[i][j + 1] instanceof Land && GamePanel.currentLifeMap[i][j + 1] == null) {
                GamePanel.currentLifeMap[i][j + 1] = GamePanel.currentLifeMap[i][j];
                GamePanel.currentLifeMap[i][j] = null;
              }
              
            // Moving Down
            } else if (direction == GamePanel.DOWN && i < 49) {
              GamePanel.currentLifeMap[i][j].currentSprite = 8;
              if (GamePanel.currentMap[i + 1][j] instanceof Land && GamePanel.currentLifeMap[i + 1][j] == null) {
                GamePanel.currentLifeMap[i + 1][j] = GamePanel.currentLifeMap[i][j];
                GamePanel.currentLifeMap[i][j] = null;
              }
            }
          }
        }
      }
    }
  }
}