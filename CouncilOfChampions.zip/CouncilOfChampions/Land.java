// [Land.java]

// Class
class Land extends Map 
{
  
  // Extends Map
  Land(int currentSprite) 
  {
    super(currentSprite);
  }
  
  // Represents an empty space where you can walk on the map
}