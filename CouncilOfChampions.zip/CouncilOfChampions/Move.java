// [Move.java]

// Import
import javax.swing.*;

// CLass
class Move 
{
  
  // Variables
  static int x, y;
  
  // Moves Player
  static void movePlayer (int x1, int y1, int x2, int y2, int direction) throws NullPointerException {
    
    // Checks if out of bounds
    if (x2 < 0 || x2 > 49 || y2 < 0 || y2 > 49) {
      return;
    }
    x = x2;
    y = y2;
    
    // If there is land
    if (GamePanel.currentMap[y2][x2] instanceof Land) {
      
      // No life
      if (GamePanel.currentLifeMap[y2][x2] == null) {
        GamePanel.currentLifeMap[y2][x2] = GamePanel.currentLifeMap[y1][x1];
        GamePanel.currentLifeMap[y1][x1] = null;
        GamePanel.movedFromSpawn = true;
        
        // If NPC
      } else if (GamePanel.currentLifeMap[y2][x2] instanceof NPC) {
        
        // Checks if you received the NPC's quest
        if (!((NPC)GamePanel.currentLifeMap[y2][x2]).receivedQuest) {
          GamePanel.quests.add(((NPC)GamePanel.currentLifeMap[y2][x2]).quest);
          ((NPC)GamePanel.currentLifeMap[y2][x2]).receivedQuest = true;
          JOptionPane.showMessageDialog(null, "Hello! Can you go kill me 5 monster #" + ((NPC)GamePanel.currentLifeMap[y2][x2]).npcNum + "? Thx m8.");
        }
        
        
      } else if (GamePanel.currentLifeMap[y2][x2] instanceof Drop) {
        GamePanel.p.gold = GamePanel.p.gold + GamePanel.currentLifeMap[y2][x2].gold;
        GamePanel.p.exp = GamePanel.p.exp + GamePanel.currentLifeMap[y2][x2].exp;
       
        // For all other life forms, checks if they are in battle
      } else if (!GamePanel.currentLifeMap[y2][x2].inBattle) {
        
        // If they aren't you fight them
        GamePanel.currentLifeMap[y2][x2].inBattle = true;
        GamePanel.currentLifeMap[y1][x1].inBattle = true;
        Question.showQuestion();
      }
      
      // If there is a building
    } else if (GamePanel.currentMap[y2][x2] instanceof Building) {
      // Weapon Shop
      if (GamePanel.currentMap[y2][x2].currentSprite == 1) {
        if (!ShopWeapons.open) {
          ShopWeapons.showWeapons();
        }
        
        // Armor Shop
      } else if (GamePanel.currentMap[y2][x2].currentSprite == 2) {
        if (!ShopShields.open) {
          ShopShields.showShields();
        }
        
        // Boss Room
      } else if (GamePanel.currentMap[y2][x2].currentSprite == 3) {
        GamePanel.currentLifeMap[y2][x2] = GamePanel.currentLifeMap[y1][x1];
        GamePanel.currentLifeMap[y1][x1] = null;
        GamePanel.movedFromSpawn = true;
      }
    }
    
    checkMaps();
    
    // Changes Sprite
    switch(direction) {
      
      // Right
      case GamePanel.RIGHT:
        GamePanel.p.currentSprite = 8;
        break;
        
        // Left
      case GamePanel.LEFT:
        GamePanel.p.currentSprite = 4;
        break;
        
        // Down
      case GamePanel.DOWN:
        GamePanel.p.currentSprite = 2;
        break;
        
        // Up
      case GamePanel.UP:
        GamePanel.p.currentSprite = 11;
        break;
      default:
        break;
    }
  }
  
  // Checks if you are leaving the map
  static void checkMaps() {
    
    // Get position
    int posX = Player.getPosX();
    int posY = Player.getPosY();
    
    // Checks if you moved from spawn
    if (GamePanel.movedFromSpawn) {
      switch(GamePanel.currentMapNum) {
        
        // Map 1
        case 0:
          
          // Go to Map 2
          if (posX == 0 && posY == 0) {
            GamePanel.resetMaps();
            GamePanel.currentMapNum = 1;
            Game.music.stop();
            Game.startMusic("Music/field1.mp3");
            GamePanel.currentLifeMap[49][49] = GamePanel.p;
            GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
            Monster.spawn(0);
            GamePanel.movedFromSpawn = false;
          
          // Go to Map 3
          } else if (posX == 49 && posY == 0) {
            GamePanel.resetMaps();
            GamePanel.currentMapNum = 2;
            Game.music.stop();
            Game.startMusic("Music/field2.mp3");
            GamePanel.currentLifeMap[49][0] = GamePanel.p;
            GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
            Monster.spawn(2);
            GamePanel.movedFromSpawn = false;
          
          // Go to Map 4
          } else if (posX == 0 && posY == 49) {
            GamePanel.resetMaps();
            GamePanel.currentMapNum = 3;
            Game.music.stop();
            Game.startMusic("Music/field3.mp3");
            GamePanel.currentLifeMap[0][49] = GamePanel.p;
            GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
            Monster.spawn(4);
            GamePanel.movedFromSpawn = false;
          
          // Go to Map 5
          } else if (posX == 49 && posY == 49) {
            GamePanel.resetMaps();
            GamePanel.currentMapNum = 4;
            Game.music.stop();
            Game.startMusic("Music/cave.mp3");
            GamePanel.currentLifeMap[0][0] = GamePanel.p;
            GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
            Monster.spawn(6);
            GamePanel.movedFromSpawn = false;
          
          // Go to Map 6
          } else if (posX == 13 && posY == 27) {
            GamePanel.resetMaps();
            GamePanel.currentMapNum = 5;
            Game.music.stop();
            Game.startMusic("Music/boss.mp3");
            GamePanel.currentLifeMap[25][25] = GamePanel.p;
            GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
            Monster.spawn(0);
            Monster.spawn(2);
            Monster.spawn(4);
            Monster.spawn(6);
            Boss.spawn();
            GamePanel.movedFromSpawn = false;
          }
          break;
        
        // Map 2
        case 1:
          if (posX == 49 && posY == 49) {
          GamePanel.resetMaps();
          GamePanel.currentMapNum = 0;
          Game.music.stop();
          Game.startMusic("Music/town.mp3");
          GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
          GamePanel.currentLifeMap[0][0] = GamePanel.p;
          NPC.spawn();
          GamePanel.movedFromSpawn = false;
        }
          break;
          
        // Map 3
        case 2:
          if (posX == 0 && posY == 49) {
          GamePanel.resetMaps();
          GamePanel.currentMapNum = 0;
          Game.music.stop();
          Game.startMusic("Music/town.mp3");
          GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
          GamePanel.currentLifeMap[0][49] = GamePanel.p;
          NPC.spawn();
          GamePanel.movedFromSpawn = false;
        }
          break;
          
        // Map 4
        case 3:
          if (posX == 49 && posY == 0) {
          GamePanel.resetMaps();
          GamePanel.currentMapNum = 0;
          Game.music.stop();
          Game.startMusic("Music/town.mp3");
          GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
          GamePanel.currentLifeMap[49][0] = GamePanel.p;
          NPC.spawn();
          GamePanel.movedFromSpawn = false;
        }
          break;
        
        // Map 5
        case 4:
          if (posX == 0 && posY == 0) {
          GamePanel.resetMaps();
          GamePanel.currentMapNum = 0;
          Game.music.stop();
          Game.startMusic("Music/town.mp3");
          GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
          GamePanel.currentLifeMap[49][49] = GamePanel.p;
          NPC.spawn();
          GamePanel.movedFromSpawn = false;
        }
          break;
          
        default:
          break;
      }
    }
  }
}