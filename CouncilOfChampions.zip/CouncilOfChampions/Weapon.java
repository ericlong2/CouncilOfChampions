// [Weapons.java]

// Imports 
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import java.util.*;

// Class
class Weapon extends Item 
{
  
  // Variables
  int attack;
  
  // Constructor
  Weapon(int cost, String name, int attack, int currentSprite) {
    super(cost, name, currentSprite);
    this.attack = attack;
  }
  
  // Spritesheet
  static BufferedImage[] sprites;
  
  // Load sprites
  static void loadSprites() throws IOException{ 
    BufferedImage sheet = ImageIO.read(new File("Image/weapon.png"));
    sprites = new BufferedImage[5 * 5];
    int width = sheet.getWidth() / 4;
    int height = sheet.getHeight() / 6;
    for (int j = 0; j < 6; j++) {
      for (int i = 0; i < 4; i++) {
        sprites[(j * 4) + i] = sheet.getSubimage(i * width, j * height, width, height);
      }
    }
  }
  
  // Load Weapons and stats
  static void load () throws IOException{
    Scanner sc = new Scanner(new File("Load/Weapon.txt"));
    while(sc.hasNext()) {
      int cost = sc.nextInt();
      String name = sc.next();
      int attack = sc.nextInt();
      int currentSprite = sc.nextInt();
      ShopWeapons.weapons.add(new Weapon(cost, name, attack, currentSprite));
    }
  }
}