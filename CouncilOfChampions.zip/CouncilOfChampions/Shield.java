// [Shield.java]

// Imports
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import java.util.*;

// Class
class Shield extends Item 
{
  
  // Variable
  int shield;
  
  // Constructor
  Shield(int cost, String name, int shield, int currentSprite) {
    super(cost, name, currentSprite);
    this.shield = shield;
  }
  
  // Spritesheet
  static BufferedImage[] sprites;
  
  // Load SPrite
  static void loadSprites() throws IOException{ 
    BufferedImage sheet = ImageIO.read(new File("Image/shield.png"));
    sprites = new BufferedImage[4 * 6];
    int width = sheet.getWidth() / 6;
    int height = sheet.getHeight() / 4;
    for (int j = 0; j < 4; j++) {
      for (int i = 0; i < 6; i++) {
        sprites[(j * 6) + i] = sheet.getSubimage(i * width, j * height, width, height);
      }
    }
  }
  
  // Load shields and stats
  static void load () throws IOException{
    Scanner sc = new Scanner(new File("Load/Shield.txt"));
    while(sc.hasNext()) {
      int cost = sc.nextInt();
      String name = sc.next();
      int shield = sc.nextInt();
      int currentSprite = sc.nextInt();
      ShopShields.shields.add(new Shield(cost, name, shield, currentSprite));
    }
  }
}