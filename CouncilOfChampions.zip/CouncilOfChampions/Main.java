// [Main.java]

// Import
import java.io.*;

// Class
class Main 
{
  
  // Starts the game
  public static void main(String[] args) throws IOException 
  {
    // Starts the menu
    Menu.startMenu();
  }
}