// [Quests.java]

// Imports
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

// Class
class Quests extends JFrame 
{
  
  // JFrame variables
  JLabel quest = new JLabel("Quest");
  JButton done = new JButton("");
  JPanel contentPane = new ImagePanel("Image/menu.png");
  JScrollPane scrollBar = new JScrollPane(contentPane, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
  
  // Constructor
  Quests () {
    
    // Set up JFrame
    setTitle("Quests");
    setSize(300,300);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
    // Quest JLabel
    quest.setFont(Menu.font);
    quest.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Done JButton
    done.setPreferredSize(new Dimension(200,50));
    done.setIcon(Menu.resize(new ImageIcon("Image/back.png"),200,50));
    done.setOpaque(false);
    done.setContentAreaFilled(false);
    done.setBorderPainted(false);
    done.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
      }
    });
    done.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // BoxLayout
    contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
    
    // Add JLabel
    contentPane.add(quest);
    
    // Add current quests
    for (int i = 0; i < GamePanel.quests.size(); i++) {
      Quest q = GamePanel.quests.get(i);
      JLabel questDetails = new JLabel(q.details);
      questDetails.setFont(Menu.font);
      JLabel questEXP = new JLabel(q.expReward + " EXP");
      questEXP.setFont(Menu.font);
      JLabel questgold = new JLabel(q.goldReward + " gold");
      questgold.setFont(Menu.font);
      contentPane.add(questDetails);
      contentPane.add(questEXP);
      contentPane.add(questgold);
    }
    
    // Add JButton
    contentPane.add(done);
    
    // Add ScrollBar
    add(scrollBar);
    
    // Resize and set visible
    pack();
    setResizable(false);
    setVisible(true);
  }
  
  // Displays quest
  static void display() {
    // Starts JFrame
    Quests quest = new Quests();
  }
  
  // Checks for completed quests
  static void checkCompletedQuests() {
    for (int i = 0; i < GamePanel.quests.size(); i++) {
      Quest q = GamePanel.quests.get(i);
      if (GamePanel.monsterDefeated[q.questNum - 1] >= 5) {
        GamePanel.p.exp = GamePanel.p.exp + q.expReward;
        GamePanel.p.gold = GamePanel.p.gold + q.goldReward;
        GamePanel.quests.remove(i);
      }
    }
  }
}