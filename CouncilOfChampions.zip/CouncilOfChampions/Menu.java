// [Menu.java]

// Imports
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.awt.image.*;
import java.util.*;
import javax.imageio.*;

// Class
class Menu extends JFrame{
  
  // Setup font and menu buttons
  static Font font = new Font("Broadway", Font.BOLD, 40);
  static Font font1 = new Font("Broadway", Font.BOLD, 10);
  static Font font2 = new Font("Monospaced", Font.BOLD, 10);
  JLabel title = new JLabel("Council of Champions");
  JButton start = new JButton();
  JButton load = new JButton();
  JButton instructions  = new JButton();
  JButton highscores = new JButton();
  JButton credits = new JButton();
  JButton exit = new JButton();
  JPanel contentPane = new ImagePanel("Image/menu.png");
  
  // Menu program
  Menu() {
    // Set up title and size on panel
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setTitle("Menu");
    setSize(600,400);
    title.setFont(font);
    title.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Start button
    start.setPreferredSize(new Dimension(200,50));
    start.setIcon(resize(new ImageIcon("Image/start.png"),200,50));
    start.setOpaque(false);
    start.setContentAreaFilled(false);
    start.setBorderPainted(false);
    start.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Arrays.fill(GamePanel.monsterDefeated, 0);
        GamePanel.bossDefeated = 0;
        GamePanel.deaths = 0;
        dispose();
        ChooseYourClass.choose();
      }
    });
    start.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Load JButton
    load.setPreferredSize(new Dimension(200,50));
    load.setIcon(resize(new ImageIcon("Image/load.png"),200,50));
    load.setOpaque(false);
    load.setContentAreaFilled(false);
    load.setBorderPainted(false);
    load.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        
        // Gets from save file
        File saveFile = new File("Save/save.txt");
        try {
          Scanner sc = new Scanner(saveFile);
          
          // Player stats
          int health = sc.nextInt();
          int exp = sc.nextInt();
          int shield = sc.nextInt();
          int attack = sc.nextInt();
          int gold = sc.nextInt();
          int classC = sc.nextInt();
          GamePanel.timePlayed = sc.nextInt();
          
          // Kills and Deaths
          for (int i = 0; i < 8; i++) {
            GamePanel.monsterDefeated[i] = sc.nextInt();
          }
          GamePanel.bossDefeated = sc.nextInt();
          GamePanel.deaths = sc.nextInt();
          
          // Inventory
          while(sc.hasNext()) {
            String weaponOrShield = sc.next();
            int cost = sc.nextInt();
            String name = sc.next();
            if (weaponOrShield.equals("w")) {
              int weaponAttack = sc.nextInt();
              int currentSprite = sc.nextInt();
              GamePanel.inventory.add(new Weapon(cost, name, weaponAttack, currentSprite));
            } else {
              int armorShield = sc.nextInt();
              int currentSprite = sc.nextInt();
              GamePanel.inventory.add(new Shield(cost, name, armorShield, currentSprite));
            }
          }
          
          // Starts the game
          Game.startGame(health, exp, shield, attack, gold, classC);
          dispose();
        } catch (IOException io) {
          System.out.println("Save file not found");
        }
      }
    });
    load.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Instructions JButton
    instructions.setPreferredSize(new Dimension(200,50));
    instructions.setIcon(resize(new ImageIcon("Image/instructions.png"),200,50));
    instructions.setOpaque(false);
    instructions.setContentAreaFilled(false);
    instructions.setBorderPainted(false);
    instructions.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
        Instructions.showInstructions();
      }
    });
    instructions.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Highscores JButton
    highscores.setPreferredSize(new Dimension(200,50));
    highscores.setIcon(resize(new ImageIcon("Image/highscores.png"),200,50));
    highscores.setOpaque(false);
    highscores.setContentAreaFilled(false);
    highscores.setBorderPainted(false);
    highscores.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
        Highscores.displayHighscores();
      }
    });
    highscores.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Credits JButton
    credits.setPreferredSize(new Dimension(200,50));
    credits.setIcon(resize(new ImageIcon("Image/credits.png"),200,50));
    credits.setOpaque(false);
    credits.setContentAreaFilled(false);
    credits.setBorderPainted(false);
    credits.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
        Credits.creditsMenu();
      }
    });
    credits.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Exit JButton
    exit.setPreferredSize(new Dimension(200,50));
    exit.setIcon(resize(new ImageIcon("Image/exit.png"),200,50));
    exit.setOpaque(false);
    exit.setContentAreaFilled(false);
    exit.setBorderPainted(false);
    exit.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
      }
    });
    exit.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // BoxLayout
    contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
    
    // Add JLabel and JButtons
    contentPane.add(title);
    contentPane.add(start);
    contentPane.add(load);
    contentPane.add(instructions);
    contentPane.add(highscores);
    contentPane.add(credits);
    contentPane.add(exit);
    
    // Add JPanel
    add(contentPane);
    
    // Resize and set visible
    pack();
    setResizable(false);
    setVisible(true);
  }
  // Opens Menu
  static void startMenu() throws IOException{
    // Creates Menu JFrame
    Menu m = new Menu();
  }
  
  static Icon resize (ImageIcon icon, int width, int height) {
    Image image = icon.getImage();
    return new ImageIcon(image.getScaledInstance(width,height,Image.SCALE_DEFAULT));
  }
}