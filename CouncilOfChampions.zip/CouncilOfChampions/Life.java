// [Life.java]

// Imports
import java.awt.image.*;
import java.util.*;

// Class
abstract class Life 
{
  
  // Variable declaration
  static Random rand;
  int health;
  int exp;
  int shield;
  int attack;
  int gold;
  int currentSprite;
  boolean inBattle;
  
  // Setting up life object
  Life(int health, int exp, int shield, int attack, int gold, int currentSprite) {
    this.health = health;
    this.exp = exp;
    this.shield = shield;
    this.attack = attack;
    this.gold = gold;
    this.currentSprite = currentSprite;
    inBattle = false;
  }
  
  Life(int currentSprite) {
    this.currentSprite = currentSprite;
  }
  
  Life(int health, int gold, int exp) {
    this.health = health;
    this.gold = gold;
    this.exp = exp;
  }
}