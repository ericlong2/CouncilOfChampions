// [Quest.java]

// Import
import javax.swing.*;

// Class
class Quest 
{
  
  // Variables
  String details;
  int expReward;
  int goldReward;
  int questNum;
  
  // Constructor
  Quest(String details, int expReward, int goldReward, int questNum) {
    this.details = details;
    this.expReward = expReward;
    this.goldReward = goldReward;
    this.questNum = questNum;
  }
}