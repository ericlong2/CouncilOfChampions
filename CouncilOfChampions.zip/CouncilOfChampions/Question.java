// [Question.java]

// Imports
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

// Class
class Question extends JFrame {
  
  // Variables
  static int answer;
  static String question;
  JLabel equation = new JLabel();
  JTextField ans = new JTextField(20);
  JButton done = new JButton("Done");
  JPanel contentPane = new JPanel();
  
  // Constructor
  Question() {
    
    // Set up JFrame
    setTitle("Question");
    setSize(300,300);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
    // Get question and answer
    get();
    
    // Equation JLabel
    equation.setFont(Menu.font);
    equation.setText(question);
    equation.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Done JButton
    done.setFont(Menu.font);
    done.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        
        // Gets submitted answer
        String s = ans.getText();
        int sol = -1;
        
        // Checks if answer is an intger
        try { 
          sol = Integer.parseInt(s); 
        } catch(Exception ex) {}
        
        // If answer is correct
        if (sol == answer) {
          
          // Subtracts from shield
          GamePanel.currentLifeMap[Move.y][Move.x].shield = GamePanel.currentLifeMap[Move.y][Move.x].shield - GamePanel.p.attack;
          
          // If  shield is destroyed, moves onto health
          if (GamePanel.currentLifeMap[Move.y][Move.x].shield < 0) {
            GamePanel.currentLifeMap[Move.y][Move.x].health = GamePanel.currentLifeMap[Move.y][Move.x].health + GamePanel.currentLifeMap[Move.y][Move.x].shield;
            GamePanel.currentLifeMap[Move.y][Move.x].shield = 0;
            
            // Tells damage dealt and health left
            JOptionPane.showMessageDialog(null, "You dealt " + GamePanel.p.attack + " damage. " + GamePanel.currentLifeMap[Move.y][Move.x].health + " health remaining.");
            
            // If no more health
            if (GamePanel.currentLifeMap[Move.y][Move.x].health <= 0) {
              
              // Removes monster or boss
              if (GamePanel.currentLifeMap[Move.y][Move.x] instanceof Monster) {
                GamePanel.monsterDefeated[((Monster)GamePanel.currentLifeMap[Move.y][Move.x]).monsterNum - 1]++;
                JOptionPane.showMessageDialog(null, "Monster " +((Monster)GamePanel.currentLifeMap[Move.y][Move.x]).monsterNum + " killed.");
              } else {
                GamePanel.bossDefeated++;
                JOptionPane.showMessageDialog(null, "Boss killed.");
                GamePanel.resetMaps(); // Resets map
                GamePanel.currentMapNum = 0; // Return to home room
                Game.music.stop();
                Game.startMusic("town.mp3");
                GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
                GamePanel.currentLifeMap[25][25] = GamePanel.p;
                NPC.spawn(); // Spawns NPCs
                GamePanel.movedFromSpawn = false;
                
              }
              GamePanel.currentLifeMap[Move.y][Move.x].inBattle = false;
              GamePanel.currentLifeMap[Move.y][Move.x] = new Drop(50, GamePanel.currentLifeMap[Move.y][Move.x].gold, GamePanel.currentLifeMap[Move.y][Move.x].exp);
              GamePanel.currentLifeMap[posY][posX].inBattle = false;
            }
          } else {
            // Tells damage dealt and health left
            JOptionPane.showMessageDialog(null, "You dealt " + GamePanel.p.attack + " damage. " + GamePanel.currentLifeMap[Move.y][Move.x].shield + " shield and " + GamePanel.currentLifeMap[Move.y][Move.x].health + " health remaining.");
          }
          
        // If Incorrect
        } else {
          
          // Subtract from player shield
          GamePanel.p.shield = GamePanel.p.shield - GamePanel.currentLifeMap[Move.y][Move.x].attack;
          
            // If shield is less than 0
            if (GamePanel.p.shield < 0) {
              
              // Add to health
              GamePanel.p.health = GamePanel.p.health + GamePanel.p.shield;
              GamePanel.p.shield = 0;
              
              // Tells enemy damage and your remaining health
              JOptionPane.showMessageDialog(null, "The enemy dealt " + GamePanel.currentLifeMap[Move.y][Move.x].attack + " damage. " + GamePanel.p.health + " health remaining.");
              
              // If health under 0
              if (GamePanel.p.health <= 0) {
                
                // Respawn
                GamePanel.deaths++; // Counts death
                JOptionPane.showMessageDialog(null, "You died."); // Death message
                GamePanel.resetMaps(); // Resets map
                GamePanel.currentMapNum = 0; // Return to home room
                Game.music.stop();
                Game.startMusic("town.mp3");
                GamePanel.currentMap = Maps.maps[GamePanel.currentMapNum];
                GamePanel.currentLifeMap[25][25] = GamePanel.p;
                NPC.spawn(); // Spawns NPCs
                GamePanel.movedFromSpawn = false;
              }
            } else {
              // Tells damage dealt and health left
              JOptionPane.showMessageDialog(null, "The enemy dealt " + GamePanel.currentLifeMap[Move.y][Move.x].attack + " damage. " + GamePanel.p.shield + " shield and " + GamePanel.p.health + " health remaining.");
        
            }
        }
        // If monster is alive, you can choose to keep fighting
        if (GamePanel.currentMapNum != 0 && GamePanel.currentLifeMap[Move.y][Move.x] != null) {
          int option = JOptionPane.showConfirmDialog(null, "Keep Fighting?");
          if (option == 0) {
            // Shows another question
            showQuestion();
          } else {
            
            // Exits combat
            GamePanel.currentLifeMap[Move.y][Move.x].inBattle = false;
            GamePanel.currentLifeMap[posY][posX].inBattle = false;
          }
          dispose();
        } else {
          dispose();
        }
            
      }
    });
    done.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // BoxLayout
    contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
    
    // Add JLabel
    contentPane.add(equation);
    
    // Add JTextField
    contentPane.add(ans);
    
    // Add JButton
    contentPane.add(done);
    
    // Add JPanel
    add(contentPane);
    
    // Resize and set visible
    pack();
    setResizable(false);
    setVisible(true);
  }
  
  // Get answer and question
  static void get() {
    
    int num1, num2, num3, type;
    
    Random rand = new Random();
    
    // Get random number
    num1 = rand.nextInt(20) + 1;
    num2 = rand.nextInt(20) + 1;
    num3 = rand.nextInt(20) + 1;
    
    // Easy Questions
    switch(Game.playerClass) 
    {
      case 1:
        // Type of question (-,+)
        type = rand.nextInt(4);
        switch(type) {
          case 0:
            
            answer = num1 + num2 + num3;
            question = num1 + " + " + num2 + " + " + num3;
            break;
            
          case 1: 
            
            answer = num1 - num2 - num3;
            question = num1 + " - " + num2 + " - " + num3;
            break;
            
          case 2: 
            
            answer = num1 + num2 - num3;
            question = num1 + " + " + num2 + " - " + num3;
            break;
            
          case 3:
            
            answer = num1 - num2 + num3;
            question = num1 + " - " + num2 + " + " + num3;
            break;
            
          default:
            break;
        }
        break;
        
      // Medium
      case 2: //(*)
        // Type of question
        type = rand.nextInt(5);
        switch(type) {
          case 0:
            answer = num1 * num2 + num3;
            question = num1 + " * " + num2 + " + " + num3;
            break;
            
          case 1:
            answer = num1 * num2 - num3;
            question = num1 + " * " + num2 + " - " + num3;
            break;
            
          case 2:
            answer = num1 * num2 * num3;
            question = num1 + " * " + num2 + " * " + num3;
            break;
            
          case 3:
            answer = num1 + num2 * num3;
            question = num1 + " + " + num2 + " * " + num3;
            break;
            
          case 4:
            answer = num1 - num2 * num3;
            question = num1 + " - " + num2 + " * " + num3;
          default:
            break;
        }
        
        
      // Hard question
      case 3:// Algebra
        
        // Type of question
        type = rand.nextInt(6);
        switch(type) {
          
          case 0:
            answer = num3;
            question = num1 + "x + " + num2 + " = " + (num1 * num3 + num2); 
            break;
            
          case 1:
            answer = num3;
            question = num1 + "x - " + num2 + " = " + (num1 * num3 - num2); 
            break;
            
          case 2:
            answer = (num3 - num2) * num1;
            question = num1 + "/x + " + num2 + " = " + num3; 
            break;
            
          case 3:
            answer = (num3 + num2) * num1;
            question = num1 + "/x - " + num2 + " = " + num3; 
            break;
            
          default:
            break;
        }
        
        break;
        
      default:
        break;
    }

  }
  static int posX;
  static int posY;
  // Shows question
  static void showQuestion() {
    // Question JFrame
    posX = Player.getPosX();
    posY = Player.getPosY();
    Question q = new Question();
  }
}