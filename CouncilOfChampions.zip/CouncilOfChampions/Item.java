// [Item.java]

// Imports
import javax.swing.*;
import java.awt.image.*;

// Class
class Item 
{
  
  // Variables for the item
  int cost;
  String name;
  int currentSprite;
  
  // Setting up parameters for the object
  Item(int cost, String name, int currentSprite) 
  {
    this.cost = cost;
    this.name = name;
    this.currentSprite = currentSprite;
  }
}