// [Player.java]

// Imports
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import java.awt.*;

// Class
class Player extends Life 
{
  
  // Variables
  static int upRow;
  static int downRow;
  static int leftCol;
  static int rightCol;
  
  // Gets player's visible area
  static void visibleArea() {
    
    // Get's position
    int posX = getPosX();
    int posY = getPosY();
    
    if (posX - 12 < 0) {
      leftCol = 0;
      rightCol = 24;
    } 
    else if (posX + 12 > 49) {
      leftCol = 25;
      rightCol = 49;
    } 
    else {
      leftCol = posX - 12;
      rightCol = posX + 12;
    }
    if (posY - 12 < 0) {
      upRow = 0;
      downRow = 24;
    } 
    else if (posY + 12 > 49) {
      upRow = 25;
      downRow = 49;
    } 
    else {
      upRow = posY - 12;
      downRow = posY + 12;
    }
  }
  
  // Constructor
  Player(int health, int exp, int shield, int attack, int gold, int currentSprite) {
    super(health, exp, shield, attack, gold, currentSprite);
  }
  
  // Spritesheet
  static BufferedImage[] sprites;
  
  // Load sprites
  static void loadSprites() throws IOException{ 
    BufferedImage sheet = ImageIO.read(new File("Image/player.png"));
    sprites = new BufferedImage[12];
    int width = sheet.getWidth() / 3;
    int height = sheet.getHeight() / 4;
    for (int j = 0; j < 4; j++) {
      for (int i = 0; i < 3; i++) {
        sprites[(j * 3) + i] = sheet.getSubimage(i * width,j * height,width,height);
      }
    }
  }
  
  // Gets x position
  static int getPosX() throws NullPointerException {
    for (int i = 0; i < 50; i++) {
      for (int j = 0; j < 50; j++) {
        if (GamePanel.currentLifeMap[i][j] instanceof Player) {
          return j;
        }
      }  
    }
    return -1;
  }
  
  // Gets y position
  static int getPosY() throws NullPointerException {
    for (int i = 0; i < 50; i++) {
      for (int j = 0; j < 50; j++) {
        if (GamePanel.currentLifeMap[i][j] instanceof Player) {
          return i;
        }
      }  
    }
    return -1;
  }
}