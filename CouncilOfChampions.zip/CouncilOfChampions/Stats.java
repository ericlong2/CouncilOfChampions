// [Stats.java]

// Imports
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

// Class
class Stats extends JFrame
{
  
  // Statistic Variables
  JLabel stats = new JLabel("Statistics");
  int timeSec = ((int)Math.round((System.nanoTime() - Game.startTime) / 1000000000)) + GamePanel.timePlayed;
  int hours = timeSec / 3600;
  int mins = (timeSec - (hours * 3600)) / 60;
  int secs = (timeSec - (hours * 3600) - (mins * 60));
  JLabel time = new JLabel("Time " + hours + " h, " + mins +  " m, " + secs + " s.");
  JLabel bossDefeated = new JLabel("Boss defeated :" + GamePanel.bossDefeated);
  JLabel deaths = new JLabel("Deaths :" + GamePanel.deaths);
  JButton back = new JButton();
  JPanel contentPane = new ImagePanel("Image/menu.png");
  
  // Constructor
  Stats() {
    
    // Set up JFrame
    setSize(600, 600);
    setTitle("Statistics");
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
    // Stats JLabel
    stats.setFont(Menu.font);
    stats.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Time JLabel
    time.setFont(Menu.font);
    time.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Boss Defeated JLabel
    bossDefeated.setFont(Menu.font);
    bossDefeated.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Deaths JLabel
    deaths.setFont(Menu.font);
    deaths.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // Back JLabel
    back.setPreferredSize(new Dimension(200,50));
    back.setIcon(Menu.resize(new ImageIcon("Image/back.png"),200,50));
    back.setOpaque(false);
    back.setContentAreaFilled(false);
    back.setBorderPainted(false);
    back.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
      }
    });
    back.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    // BoxLayout
    contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
    
    // Add JLabels
    contentPane.add(stats);
    contentPane.add(time);
    
    // Add Monster Defeated JLabels
    for (int i = 0; i < 8; i++) {
      JLabel monsterDefeated = new JLabel("Monster " + (i + 1) + " defeated :" + GamePanel.monsterDefeated[i]);
      monsterDefeated.setFont(Menu.font);
      monsterDefeated.setAlignmentX(Component.CENTER_ALIGNMENT);
      contentPane.add(monsterDefeated);
    }
    
    // Add JLabels
    contentPane.add(bossDefeated);
    contentPane.add(deaths);
    contentPane.add(back);
    
    // Add JPanel
    add(contentPane);
    
    // Resize and set visible
    pack();
    setResizable(false);
    setVisible(true);
  }
  
  // Display stats
  static void display() {
    // Stats JFrame
    Stats s = new Stats();
  }
}